package mg.videoplayer;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;

/** Simple vector-like media icons (no image resources needed). */
public class IconDrawable extends Drawable {
    public static final int PLAY = 0, PAUSE = 1, NEXT = 2, PREV = 3, REW = 4, FF = 5;

    private final int type;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint tp = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private float u, x0, y0;

    public IconDrawable(int type, int color) {
        this.type = type;
        p.setColor(color);
        p.setStyle(Paint.Style.FILL);
        tp.setColor(color);
        tp.setTextAlign(Paint.Align.CENTER);
        tp.setTypeface(Typeface.DEFAULT_BOLD);
    }

    private void tri(Canvas c, float ax, float ay, float bx, float by, float cx, float cy) {
        path.reset();
        path.moveTo(x0 + ax * u, y0 + ay * u);
        path.lineTo(x0 + bx * u, y0 + by * u);
        path.lineTo(x0 + cx * u, y0 + cy * u);
        path.close();
        c.drawPath(path, p);
    }

    private void rect(Canvas c, float l, float t, float r, float b) {
        c.drawRect(x0 + l * u, y0 + t * u, x0 + r * u, y0 + b * u, p);
    }

    @Override
    public void draw(Canvas c) {
        Rect b = getBounds();
        float s = Math.min(b.width(), b.height());
        u = s / 24f;
        x0 = b.exactCenterX() - 12 * u;
        y0 = b.exactCenterY() - 12 * u;
        switch (type) {
            case PLAY:
                tri(c, 8, 5, 8, 19, 19, 12);
                break;
            case PAUSE:
                rect(c, 6, 5, 10, 19);
                rect(c, 14, 5, 18, 19);
                break;
            case NEXT:
                tri(c, 6, 5, 6, 19, 16, 12);
                rect(c, 17, 5, 19, 19);
                break;
            case PREV:
                tri(c, 18, 5, 18, 19, 8, 12);
                rect(c, 5, 5, 7, 19);
                break;
            case REW:
                tri(c, 11, 3, 11, 13, 3, 8);
                tri(c, 20, 3, 20, 13, 12, 8);
                tp.setTextSize(9 * u);
                c.drawText("10", x0 + 12 * u, y0 + 22 * u, tp);
                break;
            case FF:
                tri(c, 13, 3, 13, 13, 21, 8);
                tri(c, 4, 3, 4, 13, 12, 8);
                tp.setTextSize(9 * u);
                c.drawText("10", x0 + 12 * u, y0 + 22 * u, tp);
                break;
        }
    }

    @Override public void setAlpha(int a) { p.setAlpha(a); tp.setAlpha(a); }
    @Override public void setColorFilter(ColorFilter f) { p.setColorFilter(f); tp.setColorFilter(f); }
    @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
}
