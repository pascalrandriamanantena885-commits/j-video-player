package mg.videoplayer;

import android.app.Activity;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.util.LruCache;
import android.view.Gravity;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

import tv.danmaku.ijk.media.player.IMediaPlayer;
import tv.danmaku.ijk.media.player.IjkMediaPlayer;

public class MainActivity extends Activity {

    static class Vid { long id; String title; String path; }

    private final ArrayList<Vid> videos = new ArrayList<Vid>();
    private final LruCache<Long, Bitmap> cache = new LruCache<Long, Bitmap>(60);
    private final Handler handler = new Handler();

    private ListView listView;
    private FrameLayout root;
    private SurfaceView sv;
    private LinearLayout controls;
    private LinearLayout topBar;
    private TextView titleView;
    private int index = 0;
    private ImageButton btn;
    private SeekBar seek;
    private TextView time;
    private IjkMediaPlayer player;
    private boolean playing = false, prepared = false, dragging = false;

    private final Runnable ticker = new Runnable() {
        public void run() {
            if (player != null && prepared) {
                long pos = player.getCurrentPosition();
                long dur = player.getDuration();
                if (dur > 0) {
                    seek.setMax((int) dur);
                    if (!dragging) seek.setProgress((int) pos);
                }
                time.setText(fmt(pos) + " / " + fmt(dur));
            }
            handler.postDelayed(this, 500);
        }
    };

    private final Runnable hider = new Runnable() {
        public void run() {
            if (player != null && prepared && player.isPlaying()) setOverlay(false);
        }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        IjkMediaPlayer.loadLibrariesOnce(null);
        loadVideos();
        listView = new ListView(this);
        listView.setAdapter(new VidAdapter());
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> p, View v, int pos, long id) {
                play(pos);
            }
        });
        showList();
    }

    private void loadVideos() {
        String[] cols = { MediaStore.Video.Media._ID, MediaStore.Video.Media.TITLE,
                MediaStore.Video.Media.DATA };
        Cursor c = getContentResolver().query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                cols, null, null, MediaStore.Video.Media.DATE_ADDED + " DESC");
        if (c == null) return;
        while (c.moveToNext()) {
            Vid v = new Vid();
            v.id = c.getLong(0);
            v.title = c.getString(1);
            v.path = c.getString(2);
            videos.add(v);
        }
        c.close();
    }

    private void showList() {
        stopPlayer();
        playing = false;
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(listView);
    }

    private void play(int i) {
        stopPlayer();
        index = i;
        final Vid v = videos.get(i);
        playing = true;
        prepared = false;
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);

        root = new FrameLayout(this);
        root.setBackgroundColor(0xFF000000);
        root.setKeepScreenOn(true);
        sv = new SurfaceView(this);
        root.addView(sv, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT,
                Gravity.CENTER));
        buildControls();
        root.setOnClickListener(new View.OnClickListener() {
            public void onClick(View x) {
                setOverlay(controls.getVisibility() != View.VISIBLE);
            }
        });
        setContentView(root);

        player = new IjkMediaPlayer();
        // Hardware decoding (MediaCodec) first; ijkplayer falls back to software (FFmpeg)
        player.setOption(IjkMediaPlayer.OPT_CATEGORY_PLAYER, "mediacodec", 1);
        player.setOption(IjkMediaPlayer.OPT_CATEGORY_PLAYER, "mediacodec-auto-rotate", 0);
        player.setOption(IjkMediaPlayer.OPT_CATEGORY_PLAYER, "mediacodec-handle-resolution-change", 0);
        // Help weak CPUs: drop late frames, skip H.264 loop filter
        player.setOption(IjkMediaPlayer.OPT_CATEGORY_PLAYER, "framedrop", 5);
        player.setOption(IjkMediaPlayer.OPT_CATEGORY_CODEC, "skip_loop_filter", 48);
        player.setOption(IjkMediaPlayer.OPT_CATEGORY_PLAYER, "start-on-prepared", 1);

        player.setOnPreparedListener(new IMediaPlayer.OnPreparedListener() {
            public void onPrepared(IMediaPlayer mp) {
                prepared = true;
                mp.start();
                btn.setImageResource(android.R.drawable.ic_media_pause);
                setOverlay(true);
            }
        });
        player.setOnVideoSizeChangedListener(new IMediaPlayer.OnVideoSizeChangedListener() {
            public void onVideoSizeChanged(IMediaPlayer mp, int w, int h, int sn, int sd) {
                fit(w, h);
            }
        });
        player.setOnCompletionListener(new IMediaPlayer.OnCompletionListener() {
            public void onCompletion(IMediaPlayer mp) {
                if (index + 1 < videos.size()) play(index + 1); else showList();
            }
        });
        player.setOnErrorListener(new IMediaPlayer.OnErrorListener() {
            public boolean onError(IMediaPlayer mp, int what, int extra) {
                fail();
                return true;
            }
        });

        sv.getHolder().addCallback(new SurfaceHolder.Callback() {
            public void surfaceCreated(SurfaceHolder h) {
                if (player == null) return;
                try {
                    player.setDisplay(h);
                    player.setDataSource(v.path);
                    player.prepareAsync();
                } catch (Exception e) {
                    fail();
                }
            }
            public void surfaceChanged(SurfaceHolder h, int f, int w, int hh) { }
            public void surfaceDestroyed(SurfaceHolder h) { }
        });
        handler.post(ticker);
    }

    private ImageButton makeBtn(int res, final Runnable action) {
        ImageButton b = new ImageButton(this);
        b.setImageResource(res);
        b.setBackgroundColor(0);
        b.setPadding(dp(18), dp(8), dp(18), dp(8));
        b.setOnClickListener(new View.OnClickListener() {
            public void onClick(View x) {
                action.run();
                setOverlay(true);
            }
        });
        return b;
    }

    private void buildControls() {
        // Top bar: back to list + title
        topBar = new LinearLayout(this);
        topBar.setBackgroundColor(0x99000000);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setPadding(dp(12), dp(10), dp(12), dp(10));
        TextView back = new TextView(this);
        back.setText("\u2190 Lisitra");
        back.setTextColor(0xFFFFFFFF);
        back.setTextSize(16);
        back.setPadding(0, 0, dp(16), 0);
        back.setOnClickListener(new View.OnClickListener() {
            public void onClick(View x) { showList(); }
        });
        topBar.addView(back);
        titleView = new TextView(this);
        titleView.setTextColor(0xFFFFFFFF);
        titleView.setTextSize(15);
        titleView.setSingleLine(true);
        titleView.setText(videos.get(index).title);
        topBar.addView(titleView);
        root.addView(topBar, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP));

        // Bottom: seek bar + time, then buttons
        controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.VERTICAL);
        controls.setBackgroundColor(0x99000000);
        controls.setPadding(dp(8), dp(4), dp(8), dp(4));

        LinearLayout row1 = new LinearLayout(this);
        row1.setGravity(Gravity.CENTER_VERTICAL);
        seek = new SeekBar(this);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean user) { }
            public void onStartTrackingTouch(SeekBar s) { dragging = true; }
            public void onStopTrackingTouch(SeekBar s) {
                dragging = false;
                if (player != null && prepared) player.seekTo(s.getProgress());
                setOverlay(true);
            }
        });
        row1.addView(seek, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        time = new TextView(this);
        time.setTextColor(0xFFFFFFFF);
        time.setText("00:00 / 00:00");
        row1.addView(time);
        controls.addView(row1);

        LinearLayout row2 = new LinearLayout(this);
        row2.setGravity(Gravity.CENTER);
        row2.addView(makeBtn(android.R.drawable.ic_media_previous, new Runnable() {
            public void run() {
                if (index > 0) play(index - 1);
                else if (player != null && prepared) player.seekTo(0);
            }
        }));
        row2.addView(makeBtn(android.R.drawable.ic_media_rew, new Runnable() {
            public void run() { seekBy(-10000); }
        }));
        btn = makeBtn(android.R.drawable.ic_media_pause, new Runnable() {
            public void run() {
                if (player == null || !prepared) return;
                if (player.isPlaying()) {
                    player.pause();
                    btn.setImageResource(android.R.drawable.ic_media_play);
                } else {
                    player.start();
                    btn.setImageResource(android.R.drawable.ic_media_pause);
                }
            }
        });
        row2.addView(btn);
        row2.addView(makeBtn(android.R.drawable.ic_media_ff, new Runnable() {
            public void run() { seekBy(10000); }
        }));
        row2.addView(makeBtn(android.R.drawable.ic_media_next, new Runnable() {
            public void run() { if (index + 1 < videos.size()) play(index + 1); }
        }));
        controls.addView(row2);

        root.addView(controls, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM));
    }

    private void seekBy(long delta) {
        if (player == null || !prepared) return;
        long p = player.getCurrentPosition() + delta;
        long d = player.getDuration();
        if (p < 0) p = 0;
        if (d > 0 && p > d - 500) p = d - 500;
        player.seekTo(p);
    }

    // Show or hide controls; when shown, auto-hide after 4 s while playing
    private void setOverlay(boolean show) {
        handler.removeCallbacks(hider);
        int vis = show ? View.VISIBLE : View.GONE;
        if (controls != null) controls.setVisibility(vis);
        if (topBar != null) topBar.setVisibility(vis);
        if (show) handler.postDelayed(hider, 4000);
    }

    private void fit(int vw, int vh) {
        int rw = root.getWidth(), rh = root.getHeight();
        if (vw <= 0 || vh <= 0 || rw <= 0 || rh <= 0) return;
        float s = Math.min((float) rw / vw, (float) rh / vh);
        sv.setLayoutParams(new FrameLayout.LayoutParams(
                (int) (vw * s), (int) (vh * s), Gravity.CENTER));
    }

    private void fail() {
        Toast.makeText(this, "Tsy afaka namaky ity video ity", Toast.LENGTH_LONG).show();
        showList();
    }

    private void stopPlayer() {
        handler.removeCallbacks(ticker);
        prepared = false;
        if (player != null) {
            try { player.release(); } catch (Exception e) { }
            player = null;
        }
    }

    private static String fmt(long ms) {
        long s = ms / 1000;
        long h = s / 3600, m = (s % 3600) / 60, sec = s % 60;
        return h > 0 ? String.format("%d:%02d:%02d", h, m, sec)
                : String.format("%02d:%02d", m, sec);
    }

    @Override
    public void onBackPressed() {
        if (playing) showList(); else super.onBackPressed();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (player != null && prepared) {
            player.pause();
            btn.setImageResource(android.R.drawable.ic_media_play);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopPlayer();
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    private class VidAdapter extends BaseAdapter {
        public int getCount() { return videos.size(); }
        public Object getItem(int i) { return videos.get(i); }
        public long getItemId(int i) { return videos.get(i).id; }

        public View getView(int pos, View convert, ViewGroup parent) {
            LinearLayout row;
            ImageView iv;
            TextView tv;
            if (convert == null) {
                row = new LinearLayout(MainActivity.this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(dp(8), dp(8), dp(8), dp(8));
                iv = new ImageView(MainActivity.this);
                iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
                row.addView(iv, new LinearLayout.LayoutParams(dp(96), dp(72)));
                tv = new TextView(MainActivity.this);
                tv.setTextSize(16);
                tv.setPadding(dp(12), 0, 0, 0);
                row.addView(tv);
            } else {
                row = (LinearLayout) convert;
                iv = (ImageView) row.getChildAt(0);
                tv = (TextView) row.getChildAt(1);
            }
            Vid v = videos.get(pos);
            tv.setText(v.title);
            iv.setTag(Long.valueOf(v.id));
            Bitmap bm = cache.get(v.id);
            if (bm != null) {
                iv.setImageBitmap(bm);
            } else {
                iv.setImageBitmap(null);
                new ThumbTask(iv, v.id).execute();
            }
            return row;
        }
    }

    private class ThumbTask extends AsyncTask<Void, Void, Bitmap> {
        private final ImageView iv;
        private final long id;
        ThumbTask(ImageView iv, long id) { this.iv = iv; this.id = id; }

        protected Bitmap doInBackground(Void... p) {
            return MediaStore.Video.Thumbnails.getThumbnail(getContentResolver(), id,
                    MediaStore.Video.Thumbnails.MICRO_KIND, null);
        }

        protected void onPostExecute(Bitmap bm) {
            if (bm == null) return;
            cache.put(id, bm);
            if (Long.valueOf(id).equals(iv.getTag())) iv.setImageBitmap(bm);
        }
    }
}
