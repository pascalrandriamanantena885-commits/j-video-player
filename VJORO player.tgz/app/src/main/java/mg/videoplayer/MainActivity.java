package mg.videoplayer;

import android.app.Activity;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.TextUtils;
import android.util.LruCache;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Locale;

import tv.danmaku.ijk.media.player.IMediaPlayer;
import tv.danmaku.ijk.media.player.IjkMediaPlayer;

public class MainActivity extends Activity {

    // ---- Fixed high-contrast palette (independent of the system light/dark mode) ----
    static final int C_BG = 0xFF0E1117;        // page background
    static final int C_HEADER = 0xFF0A0D13;    // header background
    static final int C_CARD = 0xFF1A1F2B;      // card background
    static final int C_CARD_PRESSED = 0xFF2A3142;
    static final int C_CHIP = 0xFF2A3142;
    static final int C_TEXT = 0xFFFFFFFF;      // main text  (contrast > 15:1 on card)
    static final int C_TEXT2 = 0xFFC3CBD8;     // secondary  (contrast > 8:1 on card)
    static final int C_ACCENT = 0xFF4DA3FF;
    static final int C_ON_ACCENT = 0xFF06121F;

    static class Vid {
        long id; String title; String path; long duration; long size; long added;
    }

    private static final String[] TIER_NAMES = { "HW", "SW", "Fluide" };
    private static final String[] SORT_NAMES = { "R\u00e9cent", "A\u2013Z", "Dur\u00e9e" };

    private final ArrayList<Vid> allVideos = new ArrayList<Vid>();
    private final ArrayList<Vid> videos = new ArrayList<Vid>();   // filtered + sorted
    private final LruCache<Long, Bitmap> cache = new LruCache<Long, Bitmap>(
            (int) (Runtime.getRuntime().maxMemory() / 8)) {
        @Override protected int sizeOf(Long k, Bitmap b) { return b.getByteCount(); }
    };
    private final Handler handler = new Handler();
    private SharedPreferences prefs;

    // Home screen
    private LinearLayout home;
    private GridView gridView;
    private ListView listView;
    private TextView emptyView, countView, chipGrid, chipList, chipSort;
    private EditText searchBox;
    private VidAdapter gridAdapter, listAdapter;
    private boolean gridMode = true;
    private int sortMode = 0;

    // Player screen
    private FrameLayout root;
    private SurfaceView sv;
    private SurfaceHolder holder;
    private LinearLayout controls, topBar;
    private TextView titleView, modeBtn, curTime, durTime;
    private ImageButton btn;
    private ProgressBar spinner;
    private SeekBar seek;
    private IjkMediaPlayer player;
    private int index = 0;
    private boolean playing = false, prepared = false, dragging = false;

    // Auto quality state
    private int mode = 0;          // 0 = Auto, 1..3 = manual tier (mode - 1)
    private int tier = 0;
    private int lagCount = 0;
    private int tickCount = 0;
    private int videoH = 0;
    private long startedAt = 0;

    private final Runnable ticker = new Runnable() {
        public void run() {
            if (player != null && prepared) {
                long pos = player.getCurrentPosition();
                long dur = player.getDuration();
                if (dur > 0) {
                    seek.setMax((int) dur);
                    if (!dragging) seek.setProgress((int) pos);
                }
                curTime.setText(fmt(pos));
                durTime.setText(fmt(dur));
                if ((++tickCount) % 2 == 0) adaptCheck();
            }
            handler.postDelayed(this, 500);
        }
    };

    private final Runnable hider = new Runnable() {
        public void run() {
            if (player != null && prepared && player.isPlaying()) setOverlay(false);
        }
    };

    // ======================================================================
    //  Lifecycle
    // ======================================================================

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setBackgroundDrawable(new ColorDrawable(C_BG));
        prefs = getSharedPreferences("vjoro", MODE_PRIVATE);
        mode = prefs.getInt("mode", 0);
        gridMode = prefs.getBoolean("grid", true);
        sortMode = prefs.getInt("sort", 0);
        IjkMediaPlayer.loadLibrariesOnce(null);
        loadVideos();
        buildHome();
        applyFilter();
        showList();
    }

    @Override
    public void onBackPressed() {
        if (playing) showList(); else super.onBackPressed();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (player != null && prepared) {
            player.pause();
            setPlayIcon(false);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopPlayer();
    }

    // ======================================================================
    //  UI helpers
    // ======================================================================

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable round(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    private Drawable pressable(int normal, int pressed, int radiusDp) {
        StateListDrawable s = new StateListDrawable();
        s.addState(new int[] { android.R.attr.state_pressed }, round(pressed, radiusDp));
        s.addState(new int[] {}, round(normal, radiusDp));
        return s;
    }

    private TextView text(int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private TextView chip(String label) {
        TextView t = text(14, C_TEXT, true);
        t.setText(label);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(14), dp(8), dp(14), dp(8));
        return t;
    }

    private void setChip(TextView t, boolean selected) {
        t.setBackground(round(selected ? C_ACCENT : C_CHIP, 20));
        t.setTextColor(selected ? C_ON_ACCENT : C_TEXT);
    }

    private static String fmt(long ms) {
        long s = ms / 1000;
        long h = s / 3600, m = (s % 3600) / 60, sec = s % 60;
        return h > 0 ? String.format(Locale.US, "%d:%02d:%02d", h, m, sec)
                : String.format(Locale.US, "%02d:%02d", m, sec);
    }

    private static String fmtSize(long bytes) {
        double mb = bytes / 1048576.0;
        if (mb >= 1024) return String.format(Locale.US, "%.1f Go", mb / 1024);
        return String.format(Locale.US, mb >= 100 ? "%.0f Mo" : "%.1f Mo", mb);
    }

    private static String ext(String path) {
        if (path == null) return "";
        int i = path.lastIndexOf('.');
        return i < 0 || i == path.length() - 1 ? "" : path.substring(i + 1).toUpperCase(Locale.US);
    }

    // ======================================================================
    //  Home screen (grid / list)
    // ======================================================================

    private void loadVideos() {
        String[] cols = { MediaStore.Video.Media._ID, MediaStore.Video.Media.TITLE,
                MediaStore.Video.Media.DATA, MediaStore.Video.Media.DURATION,
                MediaStore.Video.Media.SIZE, MediaStore.Video.Media.DATE_ADDED };
        Cursor c = getContentResolver().query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                cols, null, null, null);
        if (c == null) return;
        while (c.moveToNext()) {
            Vid v = new Vid();
            v.id = c.getLong(0);
            v.title = c.getString(1);
            v.path = c.getString(2);
            v.duration = c.getLong(3);
            v.size = c.getLong(4);
            v.added = c.getLong(5);
            if (v.title == null) v.title = "Video";
            allVideos.add(v);
        }
        c.close();
    }

    private void buildHome() {
        home = new LinearLayout(this);
        home.setOrientation(LinearLayout.VERTICAL);
        home.setBackgroundColor(C_BG);
        home.setFocusableInTouchMode(true);

        // --- Header ---
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setBackgroundColor(C_HEADER);
        header.setPadding(dp(16), dp(14), dp(16), dp(12));

        LinearLayout row1 = new LinearLayout(this);
        row1.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        TextView title = text(24, C_TEXT, true);
        title.setText("VJORO Player");
        countView = text(13, C_TEXT2, false);
        titles.addView(title);
        titles.addView(countView);
        row1.addView(titles, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        chipGrid = chip("Grille");
        chipList = chip("Liste");
        chipSort = chip("");
        chipGrid.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { setGridMode(true); }
        });
        chipList.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { setGridMode(false); }
        });
        chipSort.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                sortMode = (sortMode + 1) % 3;
                prefs.edit().putInt("sort", sortMode).apply();
                applyFilter();
            }
        });
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cp.leftMargin = dp(8);
        row1.addView(chipGrid, cp);
        row1.addView(chipList, cp);
        row1.addView(chipSort, cp);
        header.addView(row1);

        searchBox = new EditText(this);
        searchBox.setHint("Hitady video\u2026");
        searchBox.setHintTextColor(C_TEXT2);
        searchBox.setTextColor(C_TEXT);
        searchBox.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        searchBox.setSingleLine(true);
        searchBox.setBackground(round(C_CHIP, 24));
        searchBox.setPadding(dp(18), dp(10), dp(18), dp(10));
        searchBox.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            public void onTextChanged(CharSequence s, int a, int b, int c) { }
            public void afterTextChanged(Editable e) { applyFilter(); }
        });
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        sp.topMargin = dp(12);
        header.addView(searchBox, sp);
        home.addView(header, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // --- Content: grid + list + empty message ---
        FrameLayout content = new FrameLayout(this);

        gridView = new GridView(this);
        gridView.setNumColumns(GridView.AUTO_FIT);
        gridView.setColumnWidth(dp(190));
        gridView.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        gridView.setHorizontalSpacing(dp(12));
        gridView.setVerticalSpacing(dp(12));
        gridView.setPadding(dp(12), dp(12), dp(12), dp(12));
        gridView.setClipToPadding(false);
        gridView.setSelector(new ColorDrawable(0));
        gridAdapter = new VidAdapter(true);
        gridView.setAdapter(gridAdapter);

        listView = new ListView(this);
        listView.setDivider(new ColorDrawable(0));
        listView.setDividerHeight(dp(10));
        listView.setPadding(dp(12), dp(12), dp(12), dp(12));
        listView.setClipToPadding(false);
        listView.setSelector(new ColorDrawable(0));
        listAdapter = new VidAdapter(false);
        listView.setAdapter(listAdapter);

        AdapterView.OnItemClickListener click = new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> p, View v, int pos, long id) {
                play(pos);
            }
        };
        gridView.setOnItemClickListener(click);
        listView.setOnItemClickListener(click);

        emptyView = text(17, C_TEXT, false);
        emptyView.setGravity(Gravity.CENTER);
        emptyView.setLineSpacing(0, 1.2f);
        emptyView.setPadding(dp(32), dp(32), dp(32), dp(32));

        content.addView(gridView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        content.addView(listView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        content.addView(emptyView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        home.addView(content, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        setGridMode(gridMode);
    }

    private void setGridMode(boolean grid) {
        gridMode = grid;
        prefs.edit().putBoolean("grid", grid).apply();
        gridView.setVisibility(grid ? View.VISIBLE : View.GONE);
        listView.setVisibility(grid ? View.GONE : View.VISIBLE);
        setChip(chipGrid, grid);
        setChip(chipList, !grid);
    }

    private void applyFilter() {
        String q = searchBox.getText().toString().trim().toLowerCase(Locale.getDefault());
        videos.clear();
        for (Vid v : allVideos) {
            if (q.length() == 0 || v.title.toLowerCase(Locale.getDefault()).contains(q)) {
                videos.add(v);
            }
        }
        Collections.sort(videos, new Comparator<Vid>() {
            public int compare(Vid a, Vid b) {
                switch (sortMode) {
                    case 1: return a.title.compareToIgnoreCase(b.title);
                    case 2: return a.duration == b.duration ? 0 : (a.duration < b.duration ? 1 : -1);
                    default: return a.added == b.added ? 0 : (a.added < b.added ? 1 : -1);
                }
            }
        });
        chipSort.setText(SORT_NAMES[sortMode]);
        setChip(chipSort, false);
        countView.setText(videos.size() + " video");
        gridAdapter.notifyDataSetChanged();
        listAdapter.notifyDataSetChanged();
        if (videos.isEmpty()) {
            emptyView.setVisibility(View.VISIBLE);
            emptyView.setText(allVideos.isEmpty()
                    ? "Tsy misy video hita ao amin'ny tablette.\nAmpidiro ny rakitra video dia sokafy indray ny app."
                    : "Tsy misy video mifanaraka amin'ny fikarohana.");
        } else {
            emptyView.setVisibility(View.GONE);
        }
    }

    private void showList() {
        stopPlayer();
        playing = false;
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(home);
    }

    // ---- Adapter shared by grid and list ----

    private static class Holder {
        ImageView thumb; TextView title, sub, dur, fmt;
    }

    private class VidAdapter extends BaseAdapter {
        private final boolean grid;
        VidAdapter(boolean grid) { this.grid = grid; }

        public int getCount() { return videos.size(); }
        public Object getItem(int i) { return videos.get(i); }
        public long getItemId(int i) { return videos.get(i).id; }

        public View getView(int pos, View convert, ViewGroup parent) {
            Holder h;
            if (convert == null) {
                h = new Holder();
                convert = buildItem(h);
                convert.setTag(h);
            } else {
                h = (Holder) convert.getTag();
            }
            Vid v = videos.get(pos);
            h.title.setText(v.title);
            h.sub.setText(fmtSize(v.size));
            h.dur.setText(fmt(v.duration));
            h.fmt.setText(ext(v.path));
            h.thumb.setTag(Long.valueOf(v.id));
            Bitmap bm = cache.get(v.id);
            if (bm != null) {
                h.thumb.setImageDrawable(new ThumbDrawable(bm, dp(10), C_CHIP, C_TEXT2));
            } else {
                h.thumb.setImageDrawable(new ThumbDrawable(null, dp(10), C_CHIP, C_TEXT2));
                new ThumbTask(h.thumb, v.id).execute();
            }
            return convert;
        }

        private View buildItem(Holder h) {
            // Thumbnail with badges
            FrameLayout thumbBox = new FrameLayout(this_());
            h.thumb = new ImageView(this_());
            thumbBox.addView(h.thumb, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

            h.dur = text(11, C_TEXT, true);
            h.dur.setBackground(round(0xCC000000, 5));
            h.dur.setPadding(dp(6), dp(2), dp(6), dp(2));
            FrameLayout.LayoutParams dl = new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.BOTTOM | Gravity.RIGHT);
            dl.setMargins(0, 0, dp(6), dp(6));
            thumbBox.addView(h.dur, dl);

            h.fmt = text(10, C_ON_ACCENT, true);
            h.fmt.setBackground(round(C_ACCENT, 5));
            h.fmt.setPadding(dp(6), dp(2), dp(6), dp(2));
            FrameLayout.LayoutParams fl = new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.TOP | Gravity.LEFT);
            fl.setMargins(dp(6), dp(6), 0, 0);
            thumbBox.addView(h.fmt, fl);

            h.title = text(grid ? 15 : 16, C_TEXT, true);
            h.title.setEllipsize(TextUtils.TruncateAt.END);
            h.title.setMaxLines(2);
            h.sub = text(13, C_TEXT2, false);
            h.sub.setSingleLine(true);

            LinearLayout card = new LinearLayout(this_());
            card.setBackground(pressable(C_CARD, C_CARD_PRESSED, 14));
            if (grid) {
                card.setOrientation(LinearLayout.VERTICAL);
                card.setPadding(dp(8), dp(8), dp(8), dp(10));
                card.addView(thumbBox, new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, dp(104)));
                h.title.setLines(2);
                LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                tl.topMargin = dp(8);
                card.addView(h.title, tl);
                card.addView(h.sub);
            } else {
                card.setOrientation(LinearLayout.HORIZONTAL);
                card.setGravity(Gravity.CENTER_VERTICAL);
                card.setPadding(dp(8), dp(8), dp(12), dp(8));
                card.addView(thumbBox, new LinearLayout.LayoutParams(dp(144), dp(82)));
                LinearLayout col = new LinearLayout(this_());
                col.setOrientation(LinearLayout.VERTICAL);
                col.addView(h.title);
                col.addView(h.sub);
                LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(0,
                        ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
                cl.leftMargin = dp(14);
                card.addView(col, cl);
            }
            return card;
        }

        private MainActivity this_() { return MainActivity.this; }
    }

    private class ThumbTask extends AsyncTask<Void, Void, Bitmap> {
        private final ImageView iv;
        private final long id;
        ThumbTask(ImageView iv, long id) { this.iv = iv; this.id = id; }

        protected Bitmap doInBackground(Void... p) {
            try {
                return MediaStore.Video.Thumbnails.getThumbnail(getContentResolver(), id,
                        MediaStore.Video.Thumbnails.MINI_KIND, null);
            } catch (Throwable t) {
                return null;
            }
        }

        protected void onPostExecute(Bitmap bm) {
            if (bm == null) return;   // keep the placeholder (e.g. MKV/AVI on old Android)
            cache.put(id, bm);
            if (Long.valueOf(id).equals(iv.getTag())) {
                iv.setImageDrawable(new ThumbDrawable(bm, dp(10), C_CHIP, C_TEXT2));
            }
        }
    }

    // ======================================================================
    //  Player screen
    // ======================================================================

    private void play(int i) {
        stopPlayer();
        index = i;
        final Vid v = videos.get(i);
        playing = true;
        prepared = false;
        holder = null;
        videoH = 0;
        tier = (mode == 0) ? prefs.getInt("tier:" + v.path, 0) : mode - 1;
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);

        root = new FrameLayout(this);
        root.setBackgroundColor(0xFF000000);
        root.setKeepScreenOn(true);
        sv = new SurfaceView(this);
        root.addView(sv, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT,
                Gravity.CENTER));
        spinner = new ProgressBar(this);
        root.addView(spinner, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER));
        buildControls();
        updateModeLabel();
        root.setOnClickListener(new View.OnClickListener() {
            public void onClick(View x) {
                setOverlay(controls.getVisibility() != View.VISIBLE);
            }
        });
        setContentView(root);

        sv.getHolder().addCallback(new SurfaceHolder.Callback() {
            public void surfaceCreated(SurfaceHolder h) {
                holder = h;
                startPlayer(0);
            }
            public void surfaceChanged(SurfaceHolder h, int f, int w, int hh) { }
            public void surfaceDestroyed(SurfaceHolder h) { }
        });
        handler.post(ticker);
    }

    private void applyOptions(IjkMediaPlayer p) {
        int cat = IjkMediaPlayer.OPT_CATEGORY_PLAYER;
        int codec = IjkMediaPlayer.OPT_CATEGORY_CODEC;
        p.setOption(cat, "mediacodec", tier == 0 ? 1 : 0);
        p.setOption(cat, "mediacodec-auto-rotate", 0);
        p.setOption(cat, "mediacodec-handle-resolution-change", 0);
        p.setOption(cat, "start-on-prepared", 1);
        p.setOption(cat, "framedrop", tier == 2 ? 20 : 5);
        if (tier >= 1) {
            p.setOption(codec, "skip_loop_filter", 48);
        }
        if (tier == 2) {
            p.setOption(codec, "skip_frame", 8);
            p.setOption(codec, "lowres", 1);
        }
    }

    private void startPlayer(final long startMs) {
        releasePlayer();
        prepared = false;
        lagCount = 0;
        startedAt = System.currentTimeMillis();
        if (holder == null) return;
        spinner.setVisibility(View.VISIBLE);

        IjkMediaPlayer p = new IjkMediaPlayer();
        applyOptions(p);
        p.setOnPreparedListener(new IMediaPlayer.OnPreparedListener() {
            public void onPrepared(IMediaPlayer mp) {
                prepared = true;
                spinner.setVisibility(View.GONE);
                if (startMs > 0) mp.seekTo(startMs);
                mp.start();
                setPlayIcon(true);
                setOverlay(true);
            }
        });
        p.setOnVideoSizeChangedListener(new IMediaPlayer.OnVideoSizeChangedListener() {
            public void onVideoSizeChanged(IMediaPlayer mp, int w, int h, int sn, int sd) {
                if (h > 0 && tier < 2) videoH = h;
                fit(w, h);
            }
        });
        p.setOnCompletionListener(new IMediaPlayer.OnCompletionListener() {
            public void onCompletion(IMediaPlayer mp) {
                if (index + 1 < videos.size()) play(index + 1); else showList();
            }
        });
        p.setOnErrorListener(new IMediaPlayer.OnErrorListener() {
            public boolean onError(IMediaPlayer mp, int what, int extra) {
                if (mode == 0 && tier < 2) escalate(); else fail();
                return true;
            }
        });
        player = p;
        try {
            p.setDisplay(holder);
            p.setDataSource(videos.get(index).path);
            p.prepareAsync();
        } catch (Exception e) {
            fail();
        }
    }

    // ---- Automatic quality adaptation ----

    private float fps(String method) {
        try {
            Object r = IjkMediaPlayer.class.getMethod(method).invoke(player);
            return ((Number) r).floatValue();
        } catch (Exception e) {
            return -1f;
        }
    }

    private void adaptCheck() {
        if (mode != 0 || tier >= 2 || player == null || !prepared) return;
        if (!player.isPlaying() || dragging) return;
        if (System.currentTimeMillis() - startedAt < 5000) return;
        float dec = fps("getVideoDecodeFramesPerSecond");
        float out = fps("getVideoOutputFramesPerSecond");
        if (dec <= 0 || out <= 0) return;
        if (out / dec < 0.85f) lagCount++; else lagCount = 0;
        if (lagCount >= 3) escalate();
    }

    private void escalate() {
        long pos = (player != null && prepared) ? player.getCurrentPosition() : 0;
        int next = tier + 1;
        if (tier == 0 && videoH > 720) next = 2;
        tier = Math.min(next, 2);
        prefs.edit().putInt("tier:" + videos.get(index).path, tier).apply();
        updateModeLabel();
        Toast.makeText(this, "Qualit\u00e9 automatique : " + TIER_NAMES[tier],
                Toast.LENGTH_SHORT).show();
        startPlayer(pos);
    }

    private void cycleMode() {
        mode = (mode + 1) % 4;
        prefs.edit().putInt("mode", mode).apply();
        tier = (mode == 0) ? prefs.getInt("tier:" + videos.get(index).path, 0) : mode - 1;
        updateModeLabel();
        Toast.makeText(this, mode == 0 ? "Qualit\u00e9 : Auto" : "Qualit\u00e9 : " + TIER_NAMES[tier],
                Toast.LENGTH_SHORT).show();
        long pos = (player != null && prepared) ? player.getCurrentPosition() : 0;
        startPlayer(pos);
    }

    private void updateModeLabel() {
        if (modeBtn == null) return;
        modeBtn.setText(mode == 0 ? "Auto (" + TIER_NAMES[tier] + ")" : TIER_NAMES[mode - 1]);
    }

    // ---- Player controls ----

    private ImageButton iconBtn(int type, int sizeDp, final Runnable action) {
        ImageButton b = new ImageButton(this);
        b.setImageDrawable(new IconDrawable(type, C_TEXT));
        b.setBackgroundColor(0);
        b.setScaleType(ImageView.ScaleType.FIT_CENTER);
        int pad = dp(10);
        b.setPadding(pad, pad, pad, pad);
        b.setLayoutParams(new LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp)));
        b.setOnClickListener(new View.OnClickListener() {
            public void onClick(View x) {
                action.run();
                setOverlay(true);
            }
        });
        return b;
    }

    private void setPlayIcon(boolean isPlaying) {
        if (btn == null) return;
        btn.setImageDrawable(new IconDrawable(
                isPlaying ? IconDrawable.PAUSE : IconDrawable.PLAY, C_ON_ACCENT));
    }

    private void buildControls() {
        // ---- Top bar ----
        topBar = new LinearLayout(this);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[] { 0xE6000000, 0x00000000 }));
        topBar.setPadding(dp(14), dp(12), dp(14), dp(24));

        TextView back = chip("\u2190  Liste");
        back.setBackground(round(0xCC2A3142, 20));
        back.setOnClickListener(new View.OnClickListener() {
            public void onClick(View x) { showList(); }
        });
        topBar.addView(back);

        titleView = text(16, C_TEXT, true);
        titleView.setSingleLine(true);
        titleView.setEllipsize(TextUtils.TruncateAt.END);
        titleView.setShadowLayer(4, 0, 1, 0xFF000000);
        titleView.setText(videos.get(index).title);
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        tl.leftMargin = dp(14);
        tl.rightMargin = dp(14);
        topBar.addView(titleView, tl);

        modeBtn = chip("");
        modeBtn.setBackground(round(0xCC2A3142, 20));
        modeBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View x) {
                cycleMode();
                setOverlay(true);
            }
        });
        topBar.addView(modeBtn);
        root.addView(topBar, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP));

        // ---- Bottom controls ----
        controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.VERTICAL);
        controls.setBackground(new GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP,
                new int[] { 0xE6000000, 0x00000000 }));
        controls.setPadding(dp(16), dp(28), dp(16), dp(10));

        LinearLayout row1 = new LinearLayout(this);
        row1.setGravity(Gravity.CENTER_VERTICAL);
        curTime = text(13, C_TEXT, true);
        curTime.setShadowLayer(4, 0, 1, 0xFF000000);
        curTime.setText("00:00");
        durTime = text(13, C_TEXT, true);
        durTime.setShadowLayer(4, 0, 1, 0xFF000000);
        durTime.setText("00:00");
        seek = new SeekBar(this);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean user) {
                if (user) curTime.setText(fmt(p));
            }
            public void onStartTrackingTouch(SeekBar s) { dragging = true; }
            public void onStopTrackingTouch(SeekBar s) {
                dragging = false;
                if (player != null && prepared) player.seekTo(s.getProgress());
                setOverlay(true);
            }
        });
        row1.addView(curTime);
        row1.addView(seek, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        row1.addView(durTime);
        controls.addView(row1);

        LinearLayout row2 = new LinearLayout(this);
        row2.setGravity(Gravity.CENTER);
        row2.addView(iconBtn(IconDrawable.PREV, 52, new Runnable() {
            public void run() {
                if (index > 0) play(index - 1);
                else if (player != null && prepared) player.seekTo(0);
            }
        }));
        row2.addView(iconBtn(IconDrawable.REW, 56, new Runnable() {
            public void run() { seekBy(-10000); }
        }));
        btn = iconBtn(IconDrawable.PAUSE, 68, new Runnable() {
            public void run() {
                if (player == null || !prepared) return;
                if (player.isPlaying()) {
                    player.pause();
                    setPlayIcon(false);
                } else {
                    player.start();
                    setPlayIcon(true);
                }
            }
        });
        btn.setBackground(round(C_ACCENT, 34));
        btn.setPadding(dp(16), dp(16), dp(16), dp(16));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(dp(68), dp(68));
        bp.leftMargin = dp(12);
        bp.rightMargin = dp(12);
        btn.setLayoutParams(bp);
        setPlayIcon(true);
        row2.addView(btn);
        row2.addView(iconBtn(IconDrawable.FF, 56, new Runnable() {
            public void run() { seekBy(10000); }
        }));
        row2.addView(iconBtn(IconDrawable.NEXT, 52, new Runnable() {
            public void run() { if (index + 1 < videos.size()) play(index + 1); }
        }));
        controls.addView(row2);

        root.addView(controls, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM));
    }

    private void seekBy(long delta) {
        if (player == null || !prepared) return;
        long p = player.getCurrentPosition() + delta;
        long d = player.getDuration();
        if (p < 0) p = 0;
        if (d > 0 && p > d - 500) p = d - 500;
        player.seekTo(p);
    }

    private void setOverlay(boolean show) {
        handler.removeCallbacks(hider);
        int vis = show ? View.VISIBLE : View.GONE;
        if (controls != null) controls.setVisibility(vis);
        if (topBar != null) topBar.setVisibility(vis);
        if (show) handler.postDelayed(hider, 4000);
    }

    private void fit(int vw, int vh) {
        if (root == null || sv == null) return;
        int rw = root.getWidth(), rh = root.getHeight();
        if (vw <= 0 || vh <= 0 || rw <= 0 || rh <= 0) return;
        float s = Math.min((float) rw / vw, (float) rh / vh);
        sv.setLayoutParams(new FrameLayout.LayoutParams(
                (int) (vw * s), (int) (vh * s), Gravity.CENTER));
    }

    private void fail() {
        Toast.makeText(this, "Tsy afaka namaky ity video ity", Toast.LENGTH_LONG).show();
        showList();
    }

    private void releasePlayer() {
        if (player != null) {
            try { player.release(); } catch (Exception e) { }
            player = null;
        }
    }

    private void stopPlayer() {
        handler.removeCallbacks(ticker);
        handler.removeCallbacks(hider);
        prepared = false;
        releasePlayer();
    }
}
