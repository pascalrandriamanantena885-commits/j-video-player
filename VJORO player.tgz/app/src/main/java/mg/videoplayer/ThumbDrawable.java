package mg.videoplayer;

import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;

/** Rounded, center-cropped thumbnail. With a null bitmap it draws a placeholder with a play icon. */
public class ThumbDrawable extends Drawable {
    private final Bitmap bm;
    private final BitmapShader shader;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint icon = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Matrix m = new Matrix();
    private final RectF rect = new RectF();
    private final Path path = new Path();
    private final float radius;

    public ThumbDrawable(Bitmap bm, float radius, int bgColor, int iconColor) {
        this.bm = bm;
        this.radius = radius;
        bg.setColor(bgColor);
        icon.setColor(iconColor);
        if (bm != null) {
            shader = new BitmapShader(bm, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
            paint.setShader(shader);
        } else {
            shader = null;
        }
    }

    @Override
    public void draw(Canvas c) {
        rect.set(getBounds());
        if (bm != null) {
            float w = rect.width(), h = rect.height();
            float s = Math.max(w / bm.getWidth(), h / bm.getHeight());
            m.reset();
            m.setScale(s, s);
            m.postTranslate(rect.left + (w - bm.getWidth() * s) / 2f,
                    rect.top + (h - bm.getHeight() * s) / 2f);
            shader.setLocalMatrix(m);
            c.drawRoundRect(rect, radius, radius, paint);
        } else {
            c.drawRoundRect(rect, radius, radius, bg);
            float t = Math.min(rect.width(), rect.height()) * 0.3f;
            float cx = rect.centerX(), cy = rect.centerY();
            path.reset();
            path.moveTo(cx - t * 0.4f, cy - t * 0.6f);
            path.lineTo(cx - t * 0.4f, cy + t * 0.6f);
            path.lineTo(cx + t * 0.6f, cy);
            path.close();
            c.drawPath(path, icon);
        }
    }

    @Override public void setAlpha(int a) { paint.setAlpha(a); }
    @Override public void setColorFilter(ColorFilter f) { paint.setColorFilter(f); }
    @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
}
